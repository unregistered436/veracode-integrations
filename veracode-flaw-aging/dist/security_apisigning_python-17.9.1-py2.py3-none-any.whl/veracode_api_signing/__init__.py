# -*- coding: utf-8 -*-
# VERACODE.SOURCE.CONFIDENTIAL.VSSL-security-apisigning-python.b5f7196e3c8d51cae90d11c2f37240654e19bcc09da964086d43ce67f1f200de
#
# Copyright Veracode Inc., 2014

""" `veracode-api-signing` package.
.. moduleauthor:: Tobias Work <twork@veracode.com>
.. moduleauthor:: Darren Meyer <dmeyer@veracode.com>
.. moduleauthor:: Michael Floering <mfloering@veracode.com>
"""
import os
import sys

__author__ = 'Veracode'
__email__ = 'twork@veracode.com'
