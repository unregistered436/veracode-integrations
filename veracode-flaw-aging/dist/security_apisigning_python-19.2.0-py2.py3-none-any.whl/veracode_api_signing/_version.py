__version__ = '19.2.0'
__version_info__ = '.'.split(__version__)
